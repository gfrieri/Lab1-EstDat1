/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frieri_maldonado_primer_laboratorio;

/**
 *
 * @author gfrieri & Rmaldonado
 */
public class Frieri_Maldonado_Primer_Laboratorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Interfaz a = new Interfaz();
        a.setVisible(true);
    }

}
